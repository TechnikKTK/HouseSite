﻿using System;
using System.Web.Security;

public partial class Admin_DeleteUser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void Delete_Click(object sender, EventArgs e)
    {
        //MembershipUser user = Membership.GetUser(tbtUserKey.Text);
        
        //if (user != null)
        //{
        //    bool result = Membership.DeleteUser(user.ProviderName, true);
        //}
    }
}
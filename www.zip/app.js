﻿import { initializeApp } from "https://www.gstatic.com/firebasejs/10.4.0/firebase-app.js";

const firebaseConfig = {
    apiKey: "AIzaSyD2hUr8YSxU_-SEGbsfFnjBME_etlTZfEE",
    authDomain: "housesite-35175.firebaseapp.com",
    projectId: "housesite-35175",
    storageBucket: "housesite-35175.appspot.com",
    messagingSenderId: "325743467907",
    appId: "1:325743467907:web:cdce7d2eb115a20df52ab6",
    measurementId: "G-BM86Q96RSP"
};

// Initialize Firebase
initializeApp(firebaseConfig);

﻿import { initializeApp } from "https://www.gstatic.com/firebasejs/10.4.0/firebase-app.js";
import { getMessaging, getToken, onMessage } from "https://www.gstatic.com/firebasejs/10.4.0/firebase-messaging.js";

const firebaseConfig = {
    apiKey: "AIzaSyD2hUr8YSxU_-SEGbsfFnjBME_etlTZfEE",
    authDomain: "housesite-35175.firebaseapp.com",
    projectId: "housesite-35175",
    storageBucket: "housesite-35175.appspot.com",
    messagingSenderId: "325743467907",
    appId: "1:325743467907:web:cdce7d2eb115a20df52ab6",
    measurementId: "G-BM86Q96RSP"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const messaging = getMessaging(app);

var notification = {
    body: "It's found today at 9:39",
    click_action: "https://www.nasa.gov/feature/goddard/2016/hubble-sees-a-star-inflating-a-giant-bubble",
    icon: "https://peter-gribanov.github.io/serviceworker/Bubble-Nebula.jpg",
    image: "https://peter-gribanov.github.io/serviceworker/Bubble-Nebula_big.jpg",
    title: "Bubble Nebula"
};


onMessage(messaging, (payload) => {
    console.log('Message received. ', payload);
    // ...
});


async function getFcmToken() {
    getToken(messaging, {
        vapidKey: "BOolhDIKwbxYGInYx2V_IcA1fEyjy-o3jCbtv4pL89d7Ri9XcslDY6pu910PZNygkD6AlBNN6LX5Aroc-HObNEs"
    }).then((currentToken) => {
        if (currentToken) {
            // Send the token to your server and update the UI if necessary
            console.log(currentToken);

            $.ajax({
                url: '/SendFcm.aspx',         /* Куда пойдет запрос */
                method: 'post',             /* Метод передачи (post или get) */
                dataType: 'html',           /* Тип данных в ответе (xml, json, script, html). */
                data: { token: currentToken },     /* Параметры передаваемые в запросе. */
                success: function (data) {   /* функция которая будет выполнена после успешного запроса.  */
                    /*setTimeout(function () {*/
                    //location.href = "/dashboard";
                    //}, 3000);
                    console.log('Ok');
                }
            });

        } else {
            // Show permission request UI
            console.log('No registration token available. Request permission to generate one.');
        }
    }).catch((err) => {
        console.log('An error occurred while retrieving token. ', err);
    });    
}


//function sendMessage(currentToken, notification) {
//    fetch('https://fcm.googleapis.com/v1/projects/housesite-35175/messages:send', {
//        method: 'POST',
//        headers: {
//            'Authorization': 'Barier ' + Base64(firebaseConfig.apiKey),
//            'Content-Type': 'application/json'
//        },
//        body: JSON.stringify({
//            // Firebase loses 'image' from the notification.
//            // And you must see this: https://github.com/firebase/quickstart-js/issues/71
//            data: notification,
//            to: currentToken
//        })
//    }).then(function (response) {
//        return response.json();
//    }).then(function (json) {
//        console.log('Response', json);

//        if (json.success === 1) {
//            massage_row.show();
//            massage_id.text(json.results[0].message_id);
//        } else {
//            massage_row.hide();
//            massage_id.text(json.results[0].error);
//        }
//    }).catch(function (error) {
//        showError(error);
//    });
//}

    $(document).ready(function () {
        getFcmToken();
    });



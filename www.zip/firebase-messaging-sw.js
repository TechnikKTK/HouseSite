﻿//import { initializeApp } from "https://www.gstatic.com/firebasejs/10.4.0/firebase-app.js";
//import { getMessaging } from "https://www.gstatic.com/firebasejs/10.4.0/firebase-messaging.js";

//const app = initializeApp({
//    apiKey: "AIzaSyD2hUr8YSxU_-SEGbsfFnjBME_etlTZfEE",
//    authDomain: "housesite-35175.firebaseapp.com",
//    projectId: "housesite-35175",
//    storageBucket: "housesite-35175.appspot.com",
//    messagingSenderId: "325743467907",
//    appId: "1:325743467907:web:cdce7d2eb115a20df52ab6",
//    measurementId: "G-BM86Q96RSP"
//});

//const messaging = getMessaging(app);

//// Customize notification handler
//messaging.setBackgroundMessageHandler(function (payload) {
//    console.log('Handling background message', payload);

//    // Copy data object to get parameters in the click handler
//    payload.data.data = JSON.parse(JSON.stringify(payload.data));

//    return self.registration.showNotification(payload.data.title, payload.data);
//});

////self.addEventListener('notificationclick', function (event) {
////    const target = event.notification.data.click_action || '/';
////    event.notification.close();

////    // This looks to see if the current is already open and focuses if it is
////    event.waitUntil(clients.matchAll({
////        type: 'window',
////        includeUncontrolled: true
////    }).then(function (clientList) {
////        // clientList always is empty?!
////        for (var i = 0; i < clientList.length; i++) {
////            var client = clientList[i];
////            if (client.url === target && 'focus' in client) {
////                return client.focus();
////            }
////        }

////        return clients.openWindow(target);
////    }));
////});
